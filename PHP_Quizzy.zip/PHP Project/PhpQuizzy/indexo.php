<?php
include_once("connection.php");
include_once('header.php');
session_start();
$msg="";

if(!isset($_SESSION['username']))
{ 
    echo " Access Denied " ;
    header('location:databases.php');
	exit;   
}else{ $msg="<div class=r>Welcome, {$_SESSION['username']}</div>";}

if (isset($_GET['retry']) && $_GET['retry']=="yes"){ 
unset($_SESSION['table']);
unset($_POST);
header("Location: indexo.php");
exit;
}
if(!isset($_POST['sno'])){ 

$arr = range('a','z');
$num = range(1,9);
                $sno=1;					               
$_SESSION['sno']=$sno;
	
if (!isset($_SESSION['table'])){
$_SESSION['questions']=array();	
$qusid = range(1,32);			
$quskey = array_rand($qusid);
$qus = $qusid[$quskey];
$_SESSION['qid'] = $qus;
$_SESSION['questions'][]=$qus;
}
$str=$arr[array_rand($arr)].$num[array_rand($num)].$arr[array_rand($arr)].$arr[array_rand($arr)].$num[array_rand($num)];
$_SESSION['table'] = str_shuffle($str);
mysql_query("create table if not exists ".$_SESSION['table']."(sno int(11) null auto_increment, usrans varchar(11) not null, qid int(11), primary key(sno));") or die(mysql_error());}
elseif (isset($_POST['op'])){
$qusid = range(1,32);
$quskey = array_rand($qusid);
$qus=$qusid[$quskey];	
do {
$qusid = range(1,32);
$quskey = array_rand($qusid);
$qus=$qusid[$quskey];
}
while (in_array($qus, $_SESSION['questions']));
$_SESSION['questions'][]=$qus;
$_SESSION['qid'] = $qus;

	$sno=$_POST['sno'];
	$sno++;               
$_SESSION['sno']=$sno;

	$ans=$_POST['op'];
	$s=$_POST['s'];
                mysql_query("insert into ".$_SESSION['table']." values(null, '$ans', '$s');");
                if($sno==11){
                header("Location: results.php");
				exit;
				}
}

?>
<html><head><title>PhpQuizzy:Online Quiz Portal</title>
 

</head>
<body>

<?php
$query = mysql_query("select * from qb where sno={$_SESSION['qid']} ") or die(mysql_error());
$fetch = mysql_fetch_assoc($query) or die(mysql_error());
?>
<form name="fm" id="fm" action="" method="post">
<input type="hidden" id="sno" name="sno" value="<?php echo $_SESSION['sno']; ?>" />
<?php

echo "<table class='playform' border='0' cellpadding='15'>";
echo "<tr><td>".$_SESSION['sno']."</td><td>".$fetch['question']."</td></tr>";
echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='a'>".$fetch['a']."</td></tr>";
echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='b'>".$fetch['b']."</td></tr>";
echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='c'>".$fetch['c']."</td></tr>";echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='d'>".$fetch['d']."</td></tr>";
?>
<tr><td colspan='2'><input type="hidden" name="s" id="s" value="<?php echo $fetch['sno']; ?>"><input type="image" value="Submit" src="images/sbnrm.png" onmouseover="this.src='images/sbhvr.png'" onmouseout="this.src='images/sbnrm.png'" name="sb" id="sb"/></td></tr></table></form></div>
<div id="footer">
<center><p>Copyright &copy; 2012 </p>
 
 <br>Developed By <a href="http://www.facebook.com/">Atul Upadhyay</a></center></div></body></html>