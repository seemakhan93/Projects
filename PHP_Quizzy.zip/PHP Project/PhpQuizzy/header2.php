
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">       
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<title>PhpQuizzy:Online Quiz Portal</title>
</head>

<body>
<!--<?php echo $msg;?>-->
<pre>
<img class="poslogo" src="images/quizzy2.PNG" alt="quizzy" />
<img class="posmenu" src="images/menubar.PNG" alt="menu" />
<div class="home"><a href="databases.php">
<img src="images/nrm1.PNG" alt="Home" border="0" 
    onmouseover="this.src='images/hvr1.PNG';" 
    onmouseout="this.src='images/nrm1.PNG';" />
</a></div>

<div class="logout"><a href="signup.php">
<img src="images/nrm2.PNG" alt="logout" border="0" 
    onmouseover="this.src='images/hvr2.PNG';" 
    onmouseout="this.src='images/nrm2.PNG';" />
</a></div>

<div class="contactus"><a href="contactus.php">
<img src="images/nrm3.PNG" alt="contact" border="0" 
    onmouseover="this.src='images/hvr3.PNG';" 
    onmouseout="this.src='images/nrm3.PNG';" />
</a></div>
<div class="posboxy"><img class="poslogin" src="images/logina.PNG" alt="login" ></div>

</pre>
</body>
</html>

