<?php
include('header1.php');
?>
<img class="conimg" src="images/contactus.jpg" alt="contact" />

<div class="contxt">For any feedback, suggestion or problem related to <font color="blue">PhpQuizzy</font> contact us at 
<p>Email :atul4april@gmail.com</p>
<p>Facebook : www.facebook.com/atul4april</p>


 </div>