<?php
include "connection.php";
include('header1.php');
session_start();
$msg="";

//We only one solid isset field in the form to trigger validation.
if (isset($_POST['username'])){
    if (empty($_POST['username'])){$msg .= "<div class=\"erruname\">Please enter your username </div>";}
    if (empty($_POST['oldpass'])){$msg .= "<div class=\"erroldpass\">Please enter your old password </div>";}
    if (empty($_POST['pass1'])){$msg .= "<div class=\"errpass1\">Please enter the new password </div>";}   
    if (empty($_POST['pass2'])){$msg .= "<div class=\"errpass2\">Please enter the retype new password </div>";}
	if(trim($_POST['pass1']) != trim($_POST['pass2'])){ $msg .= "<div class=\"errmatch\">Passwords do not match</div>"; }

if (empty($msg)){
	$user = mysql_real_escape_string(trim($_POST['username']));
	$oldpass= mysql_real_escape_string(trim($_POST['oldpass']));
	$pass1 = mysql_real_escape_string(trim($_POST['pass1']));
	$pass2 = mysql_real_escape_string(trim($_POST['pass2']));

//It's much more reliable to update a record based on an id rather than a username, so grab id in query.
$sql="SELECT password FROM user WHERE username='$user' and password='$oldpass'"; 
$result= mysql_query($sql);

if (mysql_num_rows($result)){
$row = mysql_fetch_row($result);
$sql=mysql_query("UPDATE user SET password='$pass2' where username='$user'");


echo "<img class=\"cpassimgload\" src=images/loader64.gif>".
					"<div class=\"cpasssuccess\">"."Congrats $user you have successfully changed your password.<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please wait while we redirect you to the login page."."</div>";
                        header('refresh:3 databases.php');		



}
//Unless you're planning a running seperate checks for username and password, pass general message to user.
else{ $msg .="<div class=\"unamepasserr\">This Username and Password combination does not Exist.</div>";}
}
} 
  	?>   	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>PhpQuizzy:Online Quiz Portal</title>

</head>
<body><?php echo $msg; ?>



<form  method="post" action="cpass.php">


<table class="changepass" >
<tr><td>Username:</td> <td><input type="text" name="username" /></td></tr>

<tr><td>Old password:</td> <td> <input type="password" name="oldpass" /></td></tr>

<tr><td>New password:</td> <td> <input type="password" name="pass1" /></td></tr>
<tr><td>Retype New password:</td> <td> <input type="password" name="pass2" /></td></tr>

<tr><td><input class="cpassbtn" name="Submit" type="image" value="Submit" src="images/sbnrm.png" 
onmouseover="this.src='images/sbhvr.png'" onmouseout="this.src='images/sbnrm.png'" /></td></tr>

</form></table>
</body>
</html>

