<?php
$title="New user Sign up";
include('header1.php');
$msg = "";
$disp = 1;
session_start();
if(isset ($_SESSION['username']))
{
    $disp = 0;
    echo "<div class=\"already\">" .$_SESSION['username']," Already Registered .</div> ";
    header('refresh:3 index.php');
}

if($_SERVER['REQUEST_METHOD']=='POST' && 
	!empty($_POST['username']) ||
	!empty($_POST['pass1']) ||
	!empty($_POST['pass2'])
	
  )
{
	$user = trim($_POST['username']);
	$pass1 = trim($_POST['pass1']);
	$pass2 = trim($_POST['pass2']);
	if($pass1 != $pass2)
	{ $msg = "Passwords do not match"; }
	elseif($pass1=="" || $pass2=="" || $user=="") {  $msg='Empty fields not allowed ' ;}
	else 
	{
		require_once('connection.php');
		$query = "SELECT username from user where username='$user'";
		$result = mysql_query($query);
		if(mysql_num_rows($result)==1)  
		{ $msg = "User already exists, Try again ";}
		else
      {
				$clm=array("username","password"); $data=array($user,$pass1);
				$n=create("user",$clm,$data);
				if($n)	
				{
					$disp=0; echo "<img class=\"imgsign\" src=images/loader64.gif>".
					"<div class=\"newuser\">"."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thank You For Registering $user.<br> Wait While We Redirect You To The Login Page.</div>";
                        header('refresh:2 indexo.php');					
					}		
			
   	    }
	
	}
}	

if($disp==1)

	//include('header.php');
?>
<html>
<body>
<img class="sticknote" src="images/stiknote.png" alt="signup" >

<!-- <h3><a href="index.php">Home</a></h3> -->
<div class="errorsignup"><?php echo $msg; ?></div>
<form class="signup2" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<table>
<tr><td>Username:</td><td><input type="text" name="username" class="styled"/></td></tr>
<tr><td>Password:</td><td><input type="password" name="pass1" class="styled"/></td></tr>
<tr><td>Retype Password:</td><td><input type="password" name="pass2" class="styled"/></td></tr>
<tr><td></td><td colspan=20><br><input class="" name="Submit" type="image" value="Submit" src="images/sbnrm.png" onmouseover="this.src='images/sbhvr.png'" onmouseout="this.src='images/sbnrm.png'"></td></tr>
</table>
</form></body> </html>


