
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">       
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<title>PhpQuizzy:Online Quiz Portal</title>
</head>

<body>
<!--<?php echo $msg;?>-->
<img class="poslogo" src="images/quizzy2.PNG" alt="quizzy" />
<img class="posmenu" src="images/menubar.PNG" alt="menu" />
<div class="home"><a href="databases.php">
<img src="images/nrm1.PNG" alt="Home" border="0" 
    onmouseover="this.src='images/hvr1.PNG';" 
    onmouseout="this.src='images/nrm1.PNG';" />
</a></div>

<div class="logout"><a href="logout.php">
<img src="images/logoutnrm.PNG" alt="logout" border="0" 
    onmouseover="this.src='images/logouthvr.png';" 
    onmouseout="this.src='images/logoutnrm.png';" />
</a></div>

<div class="contactus"><a href="contactus.php">
<img src="images/nrm3.PNG" alt="contact" border="0" 
    onmouseover="this.src='images/hvr3.PNG';" 
    onmouseout="this.src='images/nrm3.PNG';" />
</a></div>
<form name="fm" id="fm" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" id="sno" name="sno" value="<?php echo $sno; ?>" />
<div class="posboxy"><?php
//include_once('header.php');
echo "<table class='playform' border='0' cellpadding='15'>";
echo "<tr><td>".$sno."</td><td>".$fetch['question']."</td></tr>";
echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='a'>".$fetch['a']."</td></tr>";
echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='b'>".$fetch['b']."</td></tr>";
echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='c'>".$fetch['c']."</td></tr>";echo "<tr><td colspan='2'>"."<input type='radio' name='op' value='d'>".$fetch['d']."</td></tr>";
?>
<tr><td colspan='2'><input type="hidden" name="s" id="s" value="<?php echo $fetch['sno']; ?>"><input type="image" value="Submit" src="images/sbnrm.png" onmouseover="this.src='images/sbhvr.png'" onmouseout="this.src='images/sbnrm.png'" name="sb" id="sb"/></td></tr></table></form></div>
<div id="footer">
<center><p>Copyright &copy; 2012</p>
 
 <p>Designed And Developed By <a href="www.facebook.com/mohit587">Mohit Sharma</a></p></center></div></body></html></div>


</body>
</html>

