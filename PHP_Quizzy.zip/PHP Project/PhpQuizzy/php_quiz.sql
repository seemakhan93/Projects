-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 05, 2012 at 05:29 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `php_quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `qb`
--

CREATE TABLE IF NOT EXISTS `qb` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(500) NOT NULL,
  `a` varchar(200) NOT NULL,
  `b` varchar(200) NOT NULL,
  `c` varchar(200) NOT NULL,
  `d` varchar(200) NOT NULL,
  `correctans` varchar(35) NOT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `qb`
--

INSERT INTO `qb` (`sno`, `question`, `a`, `b`, `c`, `d`, `correctans`) VALUES
(1, 'What is the full form of Php ?', 'Hypertext Pre Processor', 'Pro hyper text', 'Program hexa pro', 'None of the above', 'a'),
(2, 'What is the full form of OOP ?', 'Over other product', 'Object over programming', 'Object oriented programming', 'Our object programming', 'c'),
(3, '	What is the full form of CMS ?', 'Control management system', 'Country management system', 'Content mass system', 'Content management system', 'd'),
(4, 'What all these ( = , + , - , / ) are called in Php ?', 'Signs', 'Logical operators', 'Calculators', 'Functions', 'b'),
(5, 'How to write "Hello world" in Php ?', 'Echo "Hello world" ;', 'Write "Hello world" ;', 'Prints "Hello world" ;', 'None of the above', 'a'),
(6, 'Php is a _____ development language ?', 'Mobile', 'Computer', 'Web', 'Mac', 'c'),
(7, 'PHP server scripts are surrounded bywhich delimiters ?', '<&>gdfgdfg</&>', '<?php dgdfgdg ?>', '<?php>ffgfdgdf</?>', '<script>gdfdg</script>', 'b'),
(8, 'All variables in PHP start with which symbol?', '$', '!', '#', '%', 'a'),
(9, 'What is the correct way to end a PHP statement?', ':', ';', '+', 'None of the above', 'b'),
(10, 'How to get information from a form that is submitted using the "get" method?', 'Request.QueryString;', '$_GET[];', '@_GET()', 'GET.VARIABLE', 'b'),
(11, 'What is the correct way to create a function in PHP?', 'function myFunction()', 'create myFunction()', 'new_function myFunction()', 'Make.funtion()', 'a'),
(12, 'What is the correct way to connect to a MySQL database?', 'dbopen("localhost");', 'connect_mysql("localhost");', 'mysql_connect("localhost");', 'mysql_open("localhost");', 'c'),
(13, 'What is a correct way to add a comment in PHP?', '*..*', '<!--gfdfdfdsf-->', '<comment>......¦</comment>', '/*sdsdsdsdsd*/', 'd'),
(14, 'What is use of dot operator (.)in PHP ?', 'Multiplication', 'Concatenation', 'Separate object ', 'Delimeter', 'b'),
(15, 'Function that does continue the script execution even if the file inclusion fails?', 'None', 'require()', 'include()', 'both of above', 'c'),
(16, 'What is the full form of WAMP?', 'Windows Apache MySql Pro', 'Wire Apa My Pro', 'Windows Apache MySql Php', 'None of the above', 'c'),
(17, 'MySQL runs on which operating systems? ', 'Linux and Mac OS-X only ', 'Any operating system at all ', 'Unix, Linux, Windows and others ', 'Unix and Linux only ', 'c'),
(18, 'Which of the following can add a row to a table? ', 'Add ', 'Insert ', 'Update ', 'Alter ', 'b'),
(19, 'MySQL is a', 'A Programming language ', 'Designing language', 'A technique for writing reliable programs ', 'A Relational Database Management System ', 'd'),
(20, 'How much character are allowed to create database name? ', '55', '72', '64', '94', 'c'),
(21, 'Php & MySql are _________ projects?', 'Commercial', 'Open source', 'Restricted', 'None of the above', 'b'),
(22, 'In MySql SQL stands for ?', 'Structured que lab', 'Source quest language', 'Super query lan', 'Structured query language', 'd'),
(23, 'What is the full form of CSS ?', 'Cascading style sheet', 'Cursor style source', 'Confront summary style', 'None of the above', 'a'),
(24, 'What does $_SERVER contains ?', 'Logical structure of the domain', 'Server style information', 'Information about the ip address', 'Information about the web sever', 'd'),
(25, 'What are these AND,OR,XOR,NOR,NOT ?', 'Super Globals', 'Static operators', 'Simple operators', 'Boolean operators', 'd'),
(26, 'What is the best suited database for Php?', 'Vbase', 'Mentor', 'Oracle', 'MySql', 'd'),
(27, 'What is the full form of HTML ?', 'Hyper Text Mark Up Language', 'Hyper Mass Up Lang', 'Hello Tone Upper Lan', 'None of the above', 'a'),
(28, 'What is the latest version of CSS ?', 'Css 5', 'Css 3 ', 'Css 2.3', 'Css 2', 'b'),
(29, 'Who created Php ?', 'Bill Gates', 'Narayan Krishan Murthy', 'Ramu Kaka', 'Rasmus Lerdorf', 'd'),
(30, 'In which year Php was created ?', '1992', '1995', '1996', '2000', 'b'),
(31, 'asd', 'a', 'a', 'a', 'a', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('admin', '1'),
('mohit', '1'),
('deepi.sharda', '123456');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
