<?php
session_start();
require("connection.php");
include_once('header.php');

?>
<html>
<head>
<title>PhpQuizzy:Online Quiz Portal</title>
<link rel="stylesheet" href="style.css" type="text/css"/>
</head>
<body>
<div class="results">
<?php

$cc=0;
$query = mysql_query("select * from {$_SESSION['table']}") or die(mysql_error());
while($fetch = mysql_fetch_array($query)){
	$query_q = mysql_query("select correctans from qb where sno='{$fetch['qid']}'");
	 $fetch_q = mysql_fetch_assoc($query_q);
		if($fetch['usrans']==$fetch_q['correctans']){
		$cc++;
		}
}
if($cc>5){
echo "<img align=center src=\"images/clap.gif\" alt=\"pass\" /><p>Congrats, $_SESSION[username] You Have Passed The Quiz!";            
}else{
echo "<img align=center src=\"images/sad.gif\" alt=\"pass\" /><p>$_SESSION[username] You Have Failed The Quiz!";
} 
echo "<br /><br />";
echo "<h3><p> Your Score Is<font color=blue> ".$cc."/10 </font></p></h3><br />";
echo "<p>If You Want To Retry <a href='indexo.php?retry=yes'>Click Here.</a></p></div>";
mysql_query("DROP table ".$_SESSION['table']) or die("Error is droping!"); 
?>
</div>
</body>
</html>