<?php
$msg="";

session_start();
if(isset($_SESSION['username']))
header('location:index.php');
else { 
     if($_SERVER['REQUEST_METHOD']=='POST')
     {$user=htmlentities(trim($_POST['username']));
     $pass=htmlentities(trim($_POST['password']));
     include_once('connection.php');
     
     $query="SELECT * FROM user where username = '$user' and password='$pass'";
     $result=mysql_query($query);
     if(mysql_num_rows($result)==1) 
     
     {
     	$_SESSION['username']=$user;
     	header('location:index.php');
     	}
     	 	else {$msg="Invalid Username or Password.";}
     	mysql_free_result($result);
     	
if (isset($_POST['username']) && isset($_POST['password'])) {
// check if the username and password combination is correct
if ($_POST['username'] === 'admin' && $_POST['password'] === '1') {
// the username and password match, 
// set the session
$_SESSION['basic_is_logged_in'] = true;

// after login we move to the main page
header('Location: admin.php');

} 
}
     	
     	
     	
    
     	}
     
     }
     ?>  
     
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">             
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<title>PhpQuizzy:Online Quiz Portal</title>
	
</head>
<body>



<?php include_once('header2.php');?>
<div class="error"><?php echo $msg ;?></div>
<form class="login" action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
 <input class="username" type="text" name="username" />

<input class="pass" type="password" name="password" />
<input class="btn" name="Submit" type="image" value="Submit" src="images/button.PNG" 
onmouseover="this.src='images/btnhvr.PNG'" onmouseout="this.src='images/button.PNG'">


</form>
<a href="cpass.php" class="cpasslink" >Click here to change password</a>
</body>
</html>













