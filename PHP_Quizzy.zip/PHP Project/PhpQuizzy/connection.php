<?php
$server = 'localhost';
$username = 'root';
$password = '';
$database = 'php_quiz';
$link = mysql_connect($server, $username, $password) 
or die('Unable to connect '.mysql_error());
$db = mysql_select_db($database) 
or die('Unable to select database '.mysql_error());

function retreive($table,$data=NULL) {
	$condition="";	
	if($data!=NULL) $condition="WHERE $data";	
	$sql="SELECT * from $table $condition ";	
	$rs=mysql_query($sql);	
	return $rs;
	}

function create($table,$clm,$data) {
	if(is_array($clm) && is_array($data))	
	{
		$fields=""; $values="";
		foreach ($clm as $value)
		{ $fields=$fields.$value.","; } //comma seperate the fields  
		
		foreach ($data as $value)
		{ $values=$values."\"".$value."\","; } //comma seperate the data
		
		$fields=rtrim($fields,','); $values=rtrim($values,','); //trim trailing comma
	}	
	$sql="INSERT INTO $table ($fields) VALUES($values)";
	mysql_query($sql) or die('No record added '.mysql_error());
	 
	$n=mysql_affected_rows();
	return $n;
	}	
//retreive("polls");retreive("polls","id='1'");echo "<br>";

function update($table,$clm,$data) {
	if(is_array($clm) && is_array($data))	
	{
		$condition=array_pop($data);		
		$merge=array_combine($clm,$data);		
		$str="";
		foreach ($merge as $key => $value)
		{ $str=$str.$key."=\"".$value."\","; }   
			$str=rtrim($str,',');		
		$sql="UPDATE $table SET $str WHERE id='$condition'";
		mysql_query($sql) or die('No record Updated '.mysql_error());	
	}
}

function delrec($table,$data)
{
	$sql="DELETE from $table WHERE $data LIMIT 1";	
	mysql_query($sql) or die('No record deleted '.mysql_error());
	$n=mysql_affected_rows();
	return $n;
}
//delrec("polls","id='1'");
function auth($data)
{
	list($username,$password)=$data;
	$sql="SELECT * from user WHERE username='$username' and password='$password'";
	$rs=mysql_query($sql) or die('No record found '.mysql_error());
	if(mysql_num_rows($rs)==1)
	return $rs;
}
//$d=array("uname","passwd");auth($d);	
function check_active()
{
	$sql="SELECT * from polls WHERE status='1'";	
	$rs=mysql_query($sql) or die('Request Failed  '.mysql_error());
	if(mysql_num_rows($rs)>=1)
	return true;
	else return false;
	}
	function vote($user) 
	{
	//$sql="SELECT * FROM result WHERE id='$id' AND username='$user'";
	$sql="select polls.id, result.id from polls join result using (id) where polls.status='1' AND result.username='$user'";	
	$rs=mysql_query($sql) or die('Request Failed  '.mysql_error());
	if(mysql_num_rows($rs)>=1)
	return true;
	else return false;
}
	function votecount() {
	$sql="select polls.statement,vote, count(vote) as 'total' from polls join result using (id) where polls.status='1' group by vote";
	$rs=mysql_query($sql) or die('Request Failed  '.mysql_error());
		return $rs;	
		}

?>