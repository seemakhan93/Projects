<?php 
session_start();
include_once "connection.php";
include_once('header.php');

$msg="";


if($_SESSION['username']='admin') 
{
	 echo $msg="<div class=r>Welcome ",$_SESSION['username']."</div>";
	
}
   else {

header('refresh:3 databases.php')
	;}
	
	
	



  
if (isset($_POST["question"]) && isset($_POST["a"]) && isset($_POST["b"]) && isset($_POST["c"]) 
&& isset($_POST["d"]) && isset($_POST["correctans"]) ){
    if($_POST["question"]=="" || $_POST["a"]=="" || $_POST["b"]=="" || $_POST["c"]=="" || $_POST["d"]=="" ||
    $_POST["correctans"]=="")    
    {
    $msg = "<div class=\"adminerror\">Please Fill All The Fields </div><br/>";
    }

    
    
    
    }
   
  if($_SERVER['REQUEST_METHOD']=='POST' && 
	!empty($_POST['question']) &&
   !empty($_POST['a']) &&
	!empty($_POST['b']) &&
	!empty($_POST['c']) &&
	!empty($_POST['d']) &&
	!empty($_POST['correctans']) 
  )
  {
  $que=$_POST['question'];
  
   $o1=$_POST['a'];
  
  $o2=$_POST['b'];
  
  $o3=$_POST['c'];
  
   $o4=$_POST['d'];
  
  $ans=$_POST['correctans'];
  
  

         	
  $query="INSERT INTO qb(question,a,b,c,d,correctans) VALUES('$que','$o1','$o2','$o3','$o4','$ans') ";
         	
  $result=mysql_query($query) or die ('no records added' . mysql_error());
         	
         	         
        echo 
					"<img class=\"adminimg\" src=images/loader64.gif /><div class=\"adminque\">"."New question added ,Please wait"."<br>"."</div>";
                        header('refresh:3 admin.php');	 		
  	 	
}
?>
	
	

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">  
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<title>PhpQuizzy:Online Quiz Portal</title>
</head>
<body>
<?php echo $msg; ?></div>



<form class="admin" action="admin.php" method="POST" >

<table>
<tr><td>Question:</td> <td><input type="text" name="question" /></td></tr>
<tr><td>Option 1:</td> <td> <input type="text" name="a" /></td></tr>
<tr><td>Option 2:</td> <td> <input type="text" name="b" /></td></tr>
<tr><td>Option 3:</td> <td> <input type="text" name="c" /></td></tr>
<tr><td>Option 4:</td> <td> <input type="text" name="d" /></td></tr>
<tr><td>Correct answer:</td> <td> <SELECT name="correctans">
                 <option value="a">A
                 <option value="b">B
                 <option value="c">C
                 <option value="c">D
                 </option>
                 </select></td></tr>


<tr><td><div align="right"><input class="" name="Submit" type="image" value="Submit" src="images/sbnrm.png" 
onmouseover="this.src='images/sbhvr.png'" onmouseout="this.src='images/sbnrm.png'" /></div></td></tr>
</table>

</form>


</body>
</html>
