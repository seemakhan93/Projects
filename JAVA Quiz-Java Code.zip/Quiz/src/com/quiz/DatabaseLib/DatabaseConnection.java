package com.quiz.DatabaseLib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	
	private static DatabaseConnection instance = new DatabaseConnection();
	private Connection con = null;
	private DatabaseConnection(){}
	public static DatabaseConnection getInstance(){
		return instance;
	}
	
	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@localhost:1521:xe","system","1234");  
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  return con;
	}

}