package com.quiz.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.DatabaseLib.DatabaseConnection;

/**
 * Servlet implementation class displayquiz
 */
@WebServlet("/displayquiz")
public class displayquiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displayquiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = DatabaseConnection.getInstance()
				.getConnection();
		ArrayList<String> list=new ArrayList<>();
		HttpSession session = request.getSession();
		int id=-1;
		try {
			boolean autoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			
			list=findQuiz(request, conn,response, session);
			conn.commit();
		} catch (SQLException e) {
			System.out.println("Error in sql..."+e);
			id=-1;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}	
			
		session.setAttribute("data", list);
		ArrayList<String> ss=list;
		System.out.println("session==========");
		for(String s:ss) {
			System.out.println(s);
		}
//			response.sendRedirect("AdminHome.jsp");
			request.getRequestDispatcher("Questions.jsp").forward(request, response);
		
		
		
		
}

	private ArrayList<String> findQuiz(HttpServletRequest request, 
			Connection conn,HttpServletResponse response, HttpSession session) throws SQLException, IOException {
		String title = request.getParameter("title");
		System.out.println("displayquiz==="+title);
		 response.setContentType("text/html");
		 PrintWriter out=response.getWriter();
//        	out.println("<%@ page language=\"java\" contentType=\"text/html; charset=ISO-8859-1\"\r\n" + 
//        			"    pageEncoding=\"ISO-8859-1\"%>\r\n" + 
//        			"<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n" + 
//        			"<html>\r\n<head>\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"CSS_Sheet.css\">\r\n" + 
//        			"</head>\r\n<body>\r\n<div>\r\n<form action=\"EditQuiz \" method=\"post\">\r\n<table><tr><td><img src=\"images\\logo2.jpg\" height=\"100\" width=\"100\"/></td><td><h1 style=\"color: navy;\" >Online Quiz</h1></td>\r\n" + 
//        			"</tr>\r\n</table>\r\n\r\n<ul  >\r\n<li> <h1 style=\"color: orange;\">Welcome <%=session.getAttribute(\"firstName\")%></h1></li>\r\n" + 
//        			"  \r\n <li style=\"float: right;\"><a href=\"index.html\">Sign Out</a></li>  \r\n<li style=\"float: right;\"><a href=\"Quiz.jsp\">Edit quiz</a></li>\r\n" + 
//        			"  <li style=\"float: right;\"><a href=\"AddQuiz.jsp\">Add quiz</a></li>\r\n" + 
//        			"  <li style=\"float: right;\"><a class=\"active\" href=\"AdminProfile.jsp\">Profile</a></li>\r\n" + 
//        			"  \r\n\r\n</ul>\r\n<div>\r\n<table border=1>\r\n<tr>\r\n" + 
//        			"		<th>Title</th><th>Question Title</th><th> Option A</th><th> Option B</th><th> Option C</th>\r\n" + 
//        			"		<th>Option D</th><th>Answer</th><th> Action</th>\r\n	</tr>");
//			
//
		ArrayList<String> DataList=new ArrayList();
		String _SELECT_QUERY = new StringBuilder()
				.append(" SELECT * from questions ")
//				.append(" WHERE title=? ")
				.toString();
		PreparedStatement ps = 
				conn.prepareStatement(_SELECT_QUERY);
//		ps.setString(1, title);
		ResultSet rs = ps.executeQuery();
		String question,optA,optB,optC,optD,answer;
		while(rs.next()){
			
			DataList.add(rs.getString("title"));
			DataList.add(rs.getString("question"));
			DataList.add(rs.getString("optA"));
			DataList.add(rs.getString("optB"));
			DataList.add(rs.getString("optC"));
			DataList.add(rs.getString("optD"));
			DataList.add(rs.getString("answer"));
			
			
			
			
//			out.println("title==="+rs.getString(2));
//			out.println("question==="+rs.getString(3));
//			
			System.out.println("values:"+"==="+rs.getString(2)+"==="+rs.getString(3)+"==="+rs.getString(4)+"==="+rs.getString(5)+"==="+rs.getString(6)+"==="+rs.getString(7)+"==="+rs.getString(8)+"==="+rs.getString(3));
			System.out.println("values:");
			//out.println("<body style='background-color:#d3d3d3;'>");
//			 out.println("<tr><td><center>"+rs.getString(2)+"</td><td></center>"+"<center>"+rs.getString(3)+"</td><td><center>"+rs.getString(4)+"</center></td>"
//			 		+ "<td><center>"+rs.getString(5)+"</center></td><td><center>"+rs.getString(6)+"</center></td><td><center>"+rs.getString(7)+"</center></td><td><center>"+rs.getString(8)+"</center></td>"
//			 				+ "<td><input type=\"submit\" name=\"update\" value=\"update\"><br><input type=\"submit\" name=\"update\" value=\"update\"></td></tr>"); 
		}
//		
//		for(String i:DataList) {
//			System.out.println(i);
//		}
//		request.setAttribute("data", DataList );
////		out.println("</table>\r\n</div>\r\n</form>\r\n<input type=\"submit\" value=\"View All quiz\">\r\n</div>\r\n" + 
//				"</form>\r\n</div>\r\n\r\n</body>\r\n</html>");
		
	return DataList;
	
	}

}
