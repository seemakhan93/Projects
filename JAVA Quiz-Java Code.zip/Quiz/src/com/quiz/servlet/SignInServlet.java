package com.quiz.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.DatabaseLib.DatabaseConnection;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/SignIn")
public class SignInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignInServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection conn = DatabaseConnection.getInstance()
				.getConnection();
	  
		HttpSession session = request.getSession();
		int id=-1;
		try {
			boolean autoCommit = conn.getAutoCommit();
			conn.setAutoCommit(false);
			id = findUser(request, conn, session);
			conn.commit();
		} catch (SQLException e) {
			System.out.println("Error in sql..."+e);
			id=-1;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(id==1){
//			response.sendRedirect("AdminHome.jsp");
			request.getRequestDispatcher("AdminHome.jsp").forward(request, response);
		}else if(id>0 && id!=1)
		{
			request.getRequestDispatcher("UserHome.jsp").forward(request, response);
		}
		else{
			response.sendRedirect("invalidlogin.html");
		}
		
		
		
}

	private int findUser(HttpServletRequest request, 
			Connection conn, HttpSession session) throws SQLException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		String _SELECT_QUERY = new StringBuilder()
				.append(" SELECT * from quiz_users ")
				.append(" WHERE password=? and email=? ")
				.toString();
		PreparedStatement ps = 
				conn.prepareStatement(_SELECT_QUERY);
		ps.setString(1, password);
		ps.setString(2, email);
		ResultSet results = ps.executeQuery();
		int id = -1;
		String firstName = null;
		String lastName =null;
		String category = null;
		while(results.next()){
			id = results.getInt("id");
			firstName=results.getString("fname");
			lastName=results.getString("lname");
			
			category = results.getString("category");
			break;
		}
		System.out.println("id="+id+".......email="+email+"... name"+ firstName);
		session.setAttribute("userId", id);
		session.setAttribute("firstName", firstName);
		session.setAttribute("lastName", lastName);
		session.setAttribute("email", email);
		session.setAttribute("password", password);
		session.setAttribute("category", category);
	
		return id;
	}
	
	
	}
