package com.quiz.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.quiz.DatabaseLib.DatabaseConnection;

/**
 * Servlet implementation class SignUpservlet
 */
@WebServlet("/SignUp")
public class SignUpservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public SignUpservlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean inserted =false;
		 try {
			insertData(request);
			inserted = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			inserted = false;
		}
		 
		if(inserted)
			response.sendRedirect("SignIn.html");
		else
			response.sendRedirect("invalidlogin.html");
	}
	private void insertData(HttpServletRequest request) throws SQLException {
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String email= request.getParameter("email");
		String password = request.getParameter("password");
		
		String category= request.getParameter("category");
		System.out.println("fname="+firstName+" lname="+lastName+" categ="+category+"\\\\"+email+",.,,.,"+password);
		Connection conn = DatabaseConnection.getInstance().getConnection();
//		String insertQuery = new StringBuilder()
//				.append("INSERT INTO quiz_users(")
//				.append(" fname, lname, email, password,category )")
//				.append("VALUES(?,?,?,?,?,?)")
//		
//				.toString();
		try {
			PreparedStatement ps = conn.prepareStatement("insert into quiz_users(fname, lname, email, password, CATEGORY) values(?,?,?,?,?)");
			ps.setString(1, firstName);
			ps.setString(2, lastName);
			ps.setString(3, email);
			ps.setString(5, category);
			ps.setString(4, password);
			 ps.execute();
		} catch (SQLException e) {
			throw e;
		}
		
	}

	}

