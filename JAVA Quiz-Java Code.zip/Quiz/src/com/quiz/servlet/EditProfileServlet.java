package com.quiz.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.DatabaseLib.DatabaseConnection;

/**
 * Servlet implementation class EditProfileServlet
 */
@WebServlet("/EditProfile")
public class EditProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean updated =false;
		 try {
			updateData(request,response);
			updated = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			updated = false;
		}
		 
		if(updated)
			
			response.sendRedirect("SignIn.html");
		else
			response.sendRedirect("invalidlogin.html");
	}

	private void updateData(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String emailAddress = request.getParameter("email");
		String password = request.getParameter("password");
		
		String category= request.getParameter("category");
		
		Connection conn = DatabaseConnection.getInstance().getConnection();
	
		int id=	(Integer) request.getSession(false).getAttribute("userId");
		
//		session.setAttribute("userId", id);
//		session.setAttribute("firstName", firstName);
//		session.setAttribute("lastName", lastName);
//		session.setAttribute("email", emailAddress);
//		session.setAttribute("password", password);
//		session.setAttribute("category", category);
//	
		try {
			response.getWriter().append("UID: "+id);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		try {
			PreparedStatement ps = conn.prepareStatement("update quiz_users set fname=?, lname=?, email=?, password=?, category=? where id=?");
			ps.setString(1, firstName);
			ps.setString(2, lastName);
			
			ps.setString(3, emailAddress);
			ps.setString(5, category);
			ps.setString(4, password);
			ps.setInt(6, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			throw e;
		}
	}

}
