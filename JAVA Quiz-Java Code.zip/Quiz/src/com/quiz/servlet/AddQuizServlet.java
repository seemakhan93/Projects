package com.quiz.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.DatabaseLib.DatabaseConnection;

/**
 * Servlet implementation class AddQuizServlet
 */
@WebServlet("/AddQuiz")
public class AddQuizServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddQuizServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean inserted =false;
		HttpSession session = request.getSession();
		 try {
			insertData(request,session);
			inserted = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			inserted = false;
		}
		 
		if(inserted) {
			response.sendRedirect("AdminHome.jsp");
		}
		else
			response.sendRedirect("Error.html");
		
	}
	private void insertData(HttpServletRequest request,HttpSession session) throws SQLException {
		String title = request.getParameter("title");
		String question = request.getParameter("question");
		String optA = request.getParameter("optionA");
		String optB = request.getParameter("optionB");
		String optC = request.getParameter("optionC");
		String optD = request.getParameter("optionD");
		String answer= request.getParameter("answer");
		System.out.println(optA+"===="+optB+"===="+optC+"===="+optD);
		session.setAttribute("title", title);
		session.setAttribute("question", question);
		session.setAttribute("optionA", optA);
		session.setAttribute("optionB", optB);
		session.setAttribute("optionC", optC);
		session.setAttribute("optionD", optD);
		session.setAttribute("answer", answer);
		Connection conn = DatabaseConnection.getInstance().getConnection();
//		String insertQuery = new StringBuilder()
//				.append("INSERT INTO quiz_users(")
//				.append(" fname, lname, email, password,category )")
//				.append("VALUES(?,?,?,?,?,?)")
//		
//				.toString();
		try {
			PreparedStatement ps = conn.prepareStatement("insert into questions(title, question, optA, optB, optC,optD,answer) values(?,?,?,?,?,?,?)");
			ps.setString(1, title);
			ps.setString(2, question);
			ps.setString(3, optA);
			ps.setString(4, optB);
			ps.setString(5, optC);
			ps.setString(6, optD);
			ps.setString(7, answer);
			 ps.execute();
		} catch (SQLException e) {
			throw e;
		}
		
	}

	}

