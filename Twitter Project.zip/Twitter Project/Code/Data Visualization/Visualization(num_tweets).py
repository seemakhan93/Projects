import matplotlib.pyplot as plt
import numpy as np
import csv
num_tweets={}
with open("C:\Users\Abhi\PycharmProjects\Assignmet_1\Data Files\Data Collection\YHOO.csv","r") as csvfile:
    DataFile=csv.reader(csvfile)
    for row in DataFile:

        try:
            date = row[0].split(" ")[2]
            if date not in num_tweets.keys():
                num_tweets[date]=1
            else:
                num_tweets[date] +=1
        except IndexError:
            pass


y = num_tweets.values()
x = [1,2,3,4,5,6,7]

fig, ax = plt.subplots()
ax.plot(x,y)

ax.set(xlabel='Date (s)', ylabel='number of tweets',
       title='Daily number of TWEETS for YHOO')
ax.grid()

fig.savefig("C:\Users\Abhi\PycharmProjects\Assignmet_1\Data visualization/no.oftweets\YHOO.png")
plt.show()