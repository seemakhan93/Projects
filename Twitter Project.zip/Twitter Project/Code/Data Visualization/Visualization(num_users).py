import matplotlib.pyplot as plt
import numpy as np
import csv
import collections

num_date={}
num_users={}
with open("C:\Users\Abhi\Downloads\Altcoin.csv", "r")as csvfile:
    DataFile = csv.reader(csvfile)
    for row in DataFile:

        date = row[1].split(" ")[2]
        # print date
        user = row[2]
        if date not in num_date.keys():
            num_date[date] = 1
        else:
             num_date[date] += 1
with open("C:\Users\Abhi\Downloads\Altcoin.csv", "r")as csvfile:
    DataFile = csv.reader(csvfile)
    for row in DataFile:
        # print row[0]
        date = row[1].split(" ")[2]
        user = row[2]
        if date not in num_users.keys():
            num_users[date] = [user]
        else:
            num_users[date].append(user)


for key in num_users.keys():
    print key, "====", len(set(num_users[key]))



x = [1, 2, 3, 4, 5, 6, 7]

y=num_users.values()
fig, ax = plt.subplots()
ax.plot(x, y, marker='s', linestyle='--')

ax.set(xlabel='Days', ylabel='Number of users',
       title='Daily number of users for Altcoin')
ax.grid()

fig.savefig("C:\Users\Abhi\PycharmProjects\Assignmet_1\Data visualization\No. of users\Altcoin.png")
plt.show()