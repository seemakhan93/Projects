from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream
import json
import csv

#Variables that contains the user credentials to access Twitter API
access_token = "514548231-frQDqkpEwzfHkFdm5oqYlR3IBPiEsfwyxfe6QEwn"
access_token_secret = "u6asHqJCFVRKtSiQVfFfqI7mHHFqUEkpjYkzEl8ZgKRsA"
consumer_key = "2pw0RFuPbmMosluLfLgCHGvPC"
consumer_secret = "z7kAqkRusPyeFK4qdb7xOdBlCyW6Ae3lOr3DfwMkh75uQcNWAU"


class StdOutListener(StreamListener):
    with open("Cryptocurrency.csv", "ab") as csvfile:
        myfile = csv.writer(csvfile)
        # myfile.writerow(["tweet", "time", "user_id", "tweet_id"])
        def on_data(self, data):
        #print data
            n1=json.loads(data)
            tweet=n1['text'].encode("utf-8")
            time=n1['created_at']
            user_id=n1['user']['id']
            tweet_id=n1['id']


            print("tweet data is:",tweet)
            print("time is:",time)
            print("UserId is",user_id)
            print("tweetId is",tweet_id)

            with open("Cryptocurrency.csv","ab") as csvfile:
                 myfile=csv.writer(csvfile)

                 myfile.writerow([tweet,time,user_id,tweet_id])

            return True

    def on_error(self, status):
        print status








if __name__ == '__main__':

    #This handles Twitter authetification and the connection to Twitter Streaming API
    l = StdOutListener()
    auth = OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    stream = Stream(auth, l)

    #This line filter Twitter Streams to capture data by the keywords: 'python', 'javascript', 'ruby'
    stream.filter(track=['cryptocurrency'])