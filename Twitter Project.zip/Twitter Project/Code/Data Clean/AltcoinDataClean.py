import csv
import re
import nltk


def Reading():
    all_documents=[]
    all_id=[]
    with open("Altcoin.csv", "r") as csvfile:
        myfile = csv.reader(csvfile)
        for line in myfile:
            if line[3] not in all_id:
                tweet = line[0]
                all_documents.append(tweet)
                all_id.append(line[3])

    print(len(all_documents))
    return all_documents


def Cleaning(all_documents):
    for tweet in all_documents:
        print tweet
        # we start cleaning the data:
        tweet=re.sub(r"(?:\@|'|https?\://)\S+", "", tweet) # remove customized punctuation
        tweet = re.sub(r'[^\w\s]', '', tweet)  # remove punctuation
        tweet= re.sub("\d+", "", tweet) # remove number from text
        tokens_text=nltk.word_tokenize(tweet)
        stopwords=nltk.corpus.stopwords.words('english') #stopwards reduction
        tokens_text={w for w in tokens_text if w not in stopwords}
        print (tokens_text)

        with open("AltcoinDataClean.csv","ab") as csvfile:
            myfile = csv.writer(csvfile)
            myfile.writerow([tokens_text])



def main():
    all_documents = Reading()
    Cleaning(all_documents)

main()